# aula20260219
contém arquivos da aula do dia 19/02/2016
